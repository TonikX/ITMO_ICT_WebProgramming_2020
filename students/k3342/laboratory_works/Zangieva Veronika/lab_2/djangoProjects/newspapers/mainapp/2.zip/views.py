from rest_framework.viewsets import ModelViewSet
from django_filters.rest_framework import DjangoFilterBackend

from .models import PrintingHouse, PostOffice, Newspaper, Order, PrintRun
from .filters import PrintRunFilter, PrintRunFunc3Filter, PrintRunFunc4Filter

from mainapp.serializers import (
	PostOfficeSerializer,
	NewspaperSerializer,
	PrintingHouseSerializer,
	OrderSerializer,
	OrderSerializer_raw,
	PrintRunSerializer,
	PrintRunFunc1Ser,
	PrintRunFunc2Ser,
	PrintRunFunc3Ser,
	PrintRunFunc4Ser,
	PrintRunFunc5Ser
	)


class PostOfficeViewSet(ModelViewSet):
	serializer_class = PostOfficeSerializer
	queryset = PostOffice.objects.all()



class NewspaperViewSet(ModelViewSet):
	serializer_class = NewspaperSerializer
	queryset = Newspaper.objects.all()



class PrintingHouseViewSet(ModelViewSet):
	serializer_class = PrintingHouseSerializer
	queryset = PrintingHouse.objects.all()



class OrderViewSet(ModelViewSet):
	serializer_class = OrderSerializer
	queryset = Order.objects.all()



class OrderViewSet_raw(ModelViewSet):
	serializer_class = OrderSerializer_raw
	# pagination_class = Pagination
	queryset = Order.objects.all()


class PrintRunViewSet(ModelViewSet):
	serializer_class = PrintRunSerializer
	queryset = PrintRun.objects.all()


