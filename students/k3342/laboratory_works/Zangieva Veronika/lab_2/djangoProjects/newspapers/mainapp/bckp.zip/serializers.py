from rest_framework import serializers

from .models import PrintingHouse, PostOffice, Newspaper, Order, PrintRun


class PostOfficeSerializer(serializers.ModelSerializer):
	class Meta:
		model = PostOffice
		fields = "__all__"


class getPostOfficeNumSerializer(serializers.ModelSerializer):
	class Meta:
		model = PostOffice
		fields = ('poNum',)		


class NewspaperSerializer(serializers.ModelSerializer):
	class Meta:
		model = Newspaper
		fields = "__all__"


class PrintingHouseSerializer(serializers.ModelSerializer):
	class Meta:
		model = PrintingHouse
		fields = "__all__"


class AvaiblePrintHousesSerializer(serializers.ModelSerializer):
	class Meta:
		model = PrintingHouse
		fields = ('id',)

	# class Meta:
	# 	model = PrintingHouse
	# 	fields = ("id", "phWorkStatus")


class getNewspaperNameSerializer(serializers.ModelSerializer):
	class Meta:
		model = Newspaper
		fields = ('npName',)


class OrderSerializer_raw(serializers.ModelSerializer):
	class Meta:
		model = Order
		fields = "__all__"


class OrderSerializer(serializers.ModelSerializer):
	oPoCode = getPostOfficeNumSerializer()
	oNpCode = getNewspaperNameSerializer()
	class Meta:
		model = Order
		fields = "__all__"


class getOrdersId(serializers.ModelSerializer):
	class Meta:
		model = Order
		fields = ('id',)


class PrintRunSerializer(serializers.ModelSerializer):
	# prOcode = getOrdersId()
	class Meta:
		model = PrintRun
		fields = "__all__"


