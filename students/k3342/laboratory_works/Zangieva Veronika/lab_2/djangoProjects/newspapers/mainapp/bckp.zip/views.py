#from django.http import JsonResponse
from rest_framework.viewsets import ModelViewSet
from rest_framework.pagination import CursorPagination
from rest_framework import generics, viewsets, serializers
from rest_framework.response import Response
# from rest_framework import generics
# from django_filters.rest_framework import DjangoFilterBackend

from .models import PrintingHouse, PostOffice, Newspaper, Order, PrintRun
from mainapp.serializers import (
	PostOfficeSerializer,
	NewspaperSerializer,
	PrintingHouseSerializer,
	OrderSerializer,
	OrderSerializer_raw,
	AvaiblePrintHousesSerializer,
	PrintRunSerializer
	)



# def all_PostOffice(request):
# 	result = []
# 	postOffices = PostOffice.objects.all()
# 	for postOffice in postOffices:
# 		result.append(PostOfficeSerializer(postOffice).data)

# 	return JsonResponse(result, safe=False)



class PostOfficeViewSet(ModelViewSet):
	serializer_class = PostOfficeSerializer
	# pagination_class = Pagination
	queryset = PostOffice.objects.all()

	def filter_queryset(self, queryset):
		for k, v in self.request.query_params.items():
			if k == "cursor":
				continue
			queryset = queryset.filter(**{k: v})
		return queryset


class NewspaperViewSet(ModelViewSet):
	serializer_class = NewspaperSerializer
	# pagination_class = Pagination
	queryset = Newspaper.objects.all()

	def filter_queryset(self, queryset):
		for k, v in self.request.query_params.items():
			if k == "cursor":
				continue
			queryset = queryset.filter(**{k: v})
		return queryset


class AvaiblePrintingHouseViewSet(ModelViewSet):
	serializer_class = AvaiblePrintHousesSerializer
	# queryset = PrintingHouse.objects.all()
	queryset = PrintingHouse.objects.all()


	# def list(self, request, *args, **kwargs):
	# 	queryset = self.filter_queryset(self.get_queryset())
	# 	return Response(queryset.values_list('id', flat=True))


class PrintingHouseViewSet(ModelViewSet):
	serializer_class = PrintingHouseSerializer
	# pagination_class = Pagination
	queryset = PrintingHouse.objects.all()

	def filter_queryset(self, queryset):
		for k, v in self.request.query_params.items():
			if k == "cursor":
				continue
			queryset = queryset.filter(**{k: v})
		return queryset


class OrderViewSet(ModelViewSet):
	serializer_class = OrderSerializer
	# pagination_class = Pagination
	queryset = Order.objects.all()

	def filter_queryset(self, queryset):
		for k, v in self.request.query_params.items():
			if k == "cursor":
				continue
			queryset = queryset.filter(**{k: v})
		return queryset


class OrderViewSet_raw(ModelViewSet):
	serializer_class = OrderSerializer_raw
	# pagination_class = Pagination
	queryset = Order.objects.all()


class PrintRunViewSet(ModelViewSet):
	serializer_class = PrintRunSerializer
	queryset = PrintRun.objects.all()

	# def get_queryset(self):
	# 	queryset = PrintingHouse.objects.filter(phWorkStatus='открыта').values()
	# 	# self.get_queryset()
	# 	openedPH = queryset[:]
	# 	for phId in openedPH:
	# 		phId['id']
	# obj, created = PrintRun.objects.update_or_create(
	# 	prOCode='полученный код заказа',
	# 	prNpCode='полученный код газеты',
	# 	prPhCode= phId,
	# 	prPrintRun='вычисленный тираж'		
	# )
	# 	# UPDATE OR CREATE NEW PRINT RUN UASSIA
	# 	return queryset

