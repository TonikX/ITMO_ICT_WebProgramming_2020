from django.apps import AppConfig


class ProjectFirstAppConfig(AppConfig):
    name = 'project_first_app'
